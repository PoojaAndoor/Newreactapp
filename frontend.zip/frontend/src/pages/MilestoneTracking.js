import React, { useState, useEffect } from "react";
import axios from "axios";

const MilestoneTracking = ({ milestones }) => {
    const [editedMilestones, setEditedMilestones] = useState([]);

    // Initialize milestone data
    useEffect(() => {
        setEditedMilestones(milestones);
    }, [milestones]);

    // Handle changes in milestone fields
    const handleEdit = (index, field, value) => {
        const updatedMilestones = [...editedMilestones];
        updatedMilestones[index] = {
            ...updatedMilestones[index],
            [field]: value,
        };
        setEditedMilestones(updatedMilestones);
    };

    // ✅ Save edited milestones to the database
    const handleSave = async () => {
        try {
            const response = await axios.put("http://localhost:5000/api/milestones/save", {
                milestones: editedMilestones,
            });

            alert("Milestones saved successfully!");
        } catch (error) {
            console.error("Error saving milestones:", error);
            alert("Failed to save milestones.");
        }
    };

    return (
        <div>
            <h2>Milestone Tracking</h2>
            <table border="1" cellPadding="5">
                <thead>
                    <tr>
                        <th>Milestone ID</th>
                        <th>Milestone</th>
                        <th>Milestone Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {editedMilestones.map((milestone, index) => (
                        <tr key={milestone.MilestoneID}>
                            <td>{milestone.MilestoneID}</td>
                            <td>{milestone.Milestone}</td>
                            <td>
                                <input
                                    type="date"
                                    value={milestone.MilestoneDate || ""}
                                    onChange={(e) => handleEdit(index, "MilestoneDate", e.target.value)}
                                />
                            </td>
                            <td>
                                <select
                                    value={milestone.Status || "Pending"}
                                    onChange={(e) => handleEdit(index, "Status", e.target.value)}
                                >
                                    <option value="Pending">Pending</option>
                                    <option value="Completed">Completed</option>
                                </select>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* ✅ Save Button */}
            <button
                onClick={handleSave}
                style={{
                    marginTop: "20px",
                    padding: "10px",
                    backgroundColor: "green",
                    color: "white",
                    fontSize: "16px",
                    cursor: "pointer",
                }}
            >
                Save Changes
            </button>
        </div>
    );
};

export default MilestoneTracking;
