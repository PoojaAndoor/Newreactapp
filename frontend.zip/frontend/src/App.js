import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import OrdersPage from "./pages/OrdersPage";
import OrderTrackingPage from "./pages/OrderTrackingPage";
import PreProductionTrackingPage from "./pages/PreProductionTrackingPage";
import TaskTrackingPage from "./pages/TaskTrackingPage"; // ✅ Import Task Tracking Page

const App = () => {
  return (
    <Router>
      <Routes>
        {/* ✅ Orders Page */}
        <Route path="/" element={<OrdersPage />} />

        {/* ✅ Order Tracking Page */}
        <Route path="/ordertracking/:order_no" element={<OrderTrackingPage />} />

        {/* ✅ Pre-Production Tracking Page */}
        <Route path="/preproductiontracking" element={<PreProductionTrackingPage />} />

        {/* ✅ Task Tracking Page (New) */}
        <Route path="/task-tracking" element={<TaskTrackingPage />} />
      </Routes>
    </Router>
  );
};

export default App;
