
// module.exports = router;
const express = require("express");
const router = express.Router();
const { Order, Milestone, OrderTracking } = require("../models/model");


// Get all orders
router.get("/", async (req, res) => {
    try {
        const orders = await Order.findAll({ raw: true });
        res.json(orders);
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Add a new order
router.post("/", async (req, res) => {
    try {
        const { season, style, order_no, buyer, quantity, exfac_date, owner, status, user_id } = req.body;

        const orderData = { season, style, order_no, buyer, quantity, exfac_date, owner, status, user_id };
        const newOrder = await Order.create(orderData);
        mergeOrder(newOrder)
        res.status(201).json(newOrder);
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Update the status of an order
router.put("/:id/status", async (req, res) => {
    const { status } = req.body;
    try {
        const order = await Order.findByPk(req.params.id);
        if (!order) return res.status(404).send("Order not found");

        order.status = status;
        await order.save();
        res.status(200).send("Status updated successfully");
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Delete an order
router.delete("/:orderNo", async (req, res) => {
    const { orderNo } = req.params;
    try {
        const result = await Order.destroy({ where: { order_no: orderNo } });
        res.json({ success: true, message: "Order deleted" });
    } catch (err) {
        console.error("Delete error:", err);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// API to save selected tasks to Task Tracking table
router.post("/tasktracking", (req, res) => {
    const selectedTasks = req.body;

    if (!Array.isArray(selectedTasks) || selectedTasks.length === 0) {
        return res.status(400).json({ error: "No tasks selected" });
    }

    const values = selectedTasks.map(task => [
        task.ID,
        task.Milestone,
        task.TaskDescription,
        task.Department,
        task.MilestoneDate,
        task.Status,
    ]);

    const sql = `
        INSERT INTO task_tracking (ID, Milestone, TaskDescription, Department, MilestoneDate, Status)
        VALUES ?
    `;

    db.query(sql, [values], (err, result) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Failed to save tasks" });
        }
        res.json({ message: "Tasks saved successfully" });
    });
});

async function mergeOrder(order) {
    const milestones = await Milestone.findAll();

    const bulkData = [];
    const exFacDate = new Date(order.exfac_date);

    milestones.forEach((milestone) => {
        const calculatedDate = new Date(exFacDate);
        calculatedDate.setDate(calculatedDate.getDate() - milestone.Leadtime);

        bulkData.push({
            ID: `${order.buyer}-${order.order_no}-${milestone.Milestone}`,
            OrderNo: order.order_no,
            Customer: order.buyer,
            OrderQty: order.quantity,
            ExFacDate: order.exfac_date,
            Milestone: milestone.Milestone,
            MilestonSeqNum: milestone.MilestonSeqNum,
            TaskDescription: milestone.TaskDescription,
            Leadtime: milestone.Leadtime,
            CalculatedDate: calculatedDate.toISOString().split("T")[0],
            ApprovedDate: calculatedDate.toISOString().split("T")[0],
            MilestoneDate: calculatedDate.toISOString().split("T")[0],
            Department: milestone.Department,
            Status: "Pending",
            StatusCode: "",
            DelayDays: 0,
            DelayReason: "",
            Createdate: new Date().toISOString().split("T")[0],
            Owner: order.owner,
            Stage: "",
            ApprLeadTime: milestone.Leadtime,
            ApprDate: new Date().toISOString().split("T")[0]
        });
    });

    if (bulkData.length > 0) {
        await OrderTracking.bulkCreate(bulkData);
        console.log("OrderTracking data inserted successfully.");
    } else {
        console.log("No data to insert in OrderTracking.");
    }
}

module.exports = router;
