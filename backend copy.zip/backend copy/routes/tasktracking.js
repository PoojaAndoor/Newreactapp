  const express = require("express");
const router = express.Router();
const { OrderTracking, TaskTracking } = require("../models/model");
const { Json } = require("sequelize/lib/utils");

// ✅ Get Task Tracking Data for a Specific Order

router.get("/", async (req, res) => {
  try {
    console.log("Fetching all task tracking data...");

    const taskTracking = await TaskTracking.findAll(); // Fetch all records

    if (!taskTracking || taskTracking.length === 0) {
      return res.status(200).json([]); // Return empty array instead of 404
    }

    res.json(taskTracking);
  } catch (err) {
    console.error("Error fetching task tracking data:", err);
    res.status(500).json({ error: "Server error" });
  }
});




const getRandomStatusCode = () => {
  const statusCodes = ["D", "L", "O", "Null"];
  return statusCodes[Math.floor(Math.random() * statusCodes.length)];
};
// ✅ Add or Remove Tasks from Task Tracking

router.post("/", async (req, res) => {
  try {
    const { tasks } = req.body;

    if (!tasks || tasks.length === 0) {
      return res.status(400).json({ error: "No tasks provided" });
    }

    const existingTasks = await TaskTracking.findAll({ attributes: ["ID"], orderNo: tasks[0].orderNo });
    const existingTaskIDs = new Set(existingTasks.map((task) => task.ID));

    let tasksToAdd = tasks.filter((task) => !existingTaskIDs.has(task.ID));

    tasksToAdd = tasksToAdd.map((item) => ({
      ...item,
      StatusCode: item.StatusCode && item.StatusCode.trim() !== "" ? item.StatusCode : getRandomStatusCode(),
    }));

    console.log("Tasks to Add:", tasksToAdd);

    if (tasksToAdd.length > 0) {
      await TaskTracking.bulkCreate(tasksToAdd);
      await OrderTracking.update({SecondaryStatus: 1},{where: { ID : tasksToAdd.map(item => item.ID)}})
    }

    
    return res.status(200).json({ message: "Tasks added successfully", addedTasks: tasksToAdd.length });
  } catch (error) {
    console.error("Error updating task tracking data:", error);
    return res.status(500).json({ error: "Error updating tasks" });
  }
});


// ✅ Update a Task in Task Tracking Table
router.put("/:id", async (req, res) => {
  try {
    const { TaskDescription, Status, MilestoneDate } = req.body;
    const task = await TaskTracking.findByPk(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    await task.update({
      TaskDescription: TaskDescription || task.TaskDescription,
      Status: Status || task.Status,
      MilestoneDate: MilestoneDate || task.MilestoneDate,
    });

    return res.status(200).json({ message: "Task updated successfully" });
  } catch (error) {
    console.error("Error updating task:", error);
    return res.status(500).json({ error: "Server error" });
  }
});

// ✅ Delete a Task from Task Tracking
router.delete("/:id", async (req, res) => {
  try {
    const task = await TaskTracking.findByPk(req.params.id);

    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    const orderNo = task.OrderNo; // Get Order Number before deleting
    await task.destroy();
    console.log(`Task with ID ${req.params.id} deleted successfully`);

    // Update order tracking status for this order
    const updatedRows = await OrderTracking.update(
      { SecondaryStatus: 0 },
      { where: { OrderNo: orderNo } }
    );

    console.log(`Updated OrderTracking rows: ${updatedRows}`);
    return res.status(200).json({ message: "Task deleted successfully" });
  } catch (error) {
    console.error("Error deleting task:", error);
    return res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
