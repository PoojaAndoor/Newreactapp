// const express = require("express");
// const router = express.Router();
// const { Order, Milestone, OrderTracking } = require("../models/model");

// router.get("/:orderno", async (req, res) => {
//     console.log('1111111111111111111111111111111111',req.params.orderno)
//     try {
//         const orderTracking = await OrderTracking.findAll({ where: { OrderNo: req.params.orderno } });
//         res.json(orderTracking);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send("Server error");
//     }
// });

// router.put("/:id", async (req, res) => {
//     try {
//         const updatedData = req.body;
//         await OrderTracking.update(updatedData, {
//             where: { ID: req.params.id },
//         });
//         const updatedOrderTracking = await OrderTracking.findAll({
//             where: { OrderNo: req.body.OrderNo },
//         });

//         res.json(updatedOrderTracking);
//     } catch (err) {
//         console.error("Error updating OrderTracking:", err);
//         res.status(500).send("Server error");
//     }
// });

// router.get("/orders/milestones", async (req, res) => {
//     console.log('1111111111111111')
//     try {
//         const orders = await Order.findAll({
//             include: [
//                 {
//                     model: OrderTracking,
//                     attributes: ["Milestone", "MilestoneDate"],
//                 },
//             ],
//         });

//         if (!orders.length) {
//             console.log("No orders found");
//             return;
//         }

//         const result = orders.map(order => {
//             const milestones = {};
//             order.OrderTrackings.forEach(tracking => {
//                 milestones[tracking.Milestone] = tracking.MilestoneDate;
//             });

//             return {
//                 season: order.season,
//                 style: order.style,
//                 orderNo: order.order_no,
//                 buyer: order.buyer,
//                 owner: order.owner,
//                 quantity: order.quantity,
//                 milestones,
//             };
//         });
//         // console.log(result)
//         return res.json(result);
//     } catch (err) {
//         console.error("Error fetching orders and milestones:", err);
//         return res.status(500).send('Erroe while fecthing data')
//     }
// });

// /*CREATE TABLE ordertracking(
//     ID VARCHAR(255) PRIMARY KEY,
//     OrderNo VARCHAR(50) NOT NULL,
//     Customer VARCHAR(100) NOT NULL,
//     OrderQty INT NOT NULL,
//     ExFacDate DATE NOT NULL,
//     Milestone VARCHAR(100) NOT NULL,
//     MilestonSeqNum INT NOT NULL,
//     TaskDescription VARCHAR(255) NOT NULL,
//     Leadtime INT NOT NULL,
//     CalculatedDate DATE NOT NULL,
//     ApprovedDate DATE NOT NULL,
//     MilestoneDate DATE NOT NULL,
//     Department VARCHAR(100),
//     Status VARCHAR(50) DEFAULT 'Pending',
//     StatusCode VARCHAR(10),
//     DelayDays INT DEFAULT 0,
//     DelayReason TEXT,
//     Createdate DATE NOT NULL,
//     Owner VARCHAR(100),
//     Stage VARCHAR(50),
//     ApprLeadTime INT,
//     ApprDate DATE NOT NULL
// );*/

// async function mergeOrder() {
//     const orders = await Order.findAll();
//     const milestones = await Milestone.findAll();
//     const bulkData = [];

//     for (const order of orders) {
//         const exFacDate = new Date(order.exfac_date);
//         milestones.forEach((milestone, index) => {
//             const calculatedDate = new Date(exFacDate);
//             calculatedDate.setDate(calculatedDate.getDate() - milestone.Leadtime);

//             bulkData.push({
//                 ID: `${order.buyer}-${order.order_no}-${milestone.Milestone}`,
//                 OrderNo: order.order_no,
//                 Customer: order.buyer,
//                 OrderQty: order.quantity,
//                 ExFacDate: order.exfac_date,
//                 Milestone: milestone.Milestone,
//                 MilestonSeqNum: milestone.MilestonSeqNum,
//                 TaskDescription: milestone.TaskDescription,
//                 Leadtime: milestone.Leadtime,
//                 CalculatedDate: calculatedDate.toISOString().split("T")[0],
//                 ApprovedDate: calculatedDate.toISOString().split("T")[0],
//                 MilestoneDate: calculatedDate.toISOString().split("T")[0],
//                 Department: milestone.Department,
//                 Status: "Pending",
//                 StatusCode: "",
//                 DelayDays: 0,
//                 DelayReason: "",
//                 Createdate: new Date().toISOString().split("T")[0],
//                 Owner: order.owner,
//                 Stage: "",
//                 ApprLeadTime: milestone.Leadtime,
//                 ApprDate: new Date().toISOString().split("T")[0]
//             });
//         });
//     }

//     await OrderTracking.bulkCreate(bulkData);
// }
//  //mergeOrder()

// module.exports = router;
const express = require("express");
const router = express.Router();
const { Order, Milestone, OrderTracking, TaskTracking } = require("../models/model");

// Fetch order tracking by OrderNo
router.get("/:orderno", async (req, res) => {
    console.log("Fetching order tracking for Order No:", req.params.orderno);
    try {
        const orderTracking = await OrderTracking.findAll({ where: { OrderNo: req.params.orderno } });
        console.log("OrderTracking data:", orderTracking);
        
        if (orderTracking.length === 0) {
            return res.status(404).json({ message: "No tracking data found for this order." });
        }

        //  await TaskTracking.destroy({
        //     where: {},
        //     truncate: true
        //   });
        res.json(orderTracking);
    } catch (err) {
        console.error("Error fetching order tracking:", err);
        res.status(500).send("Server error");
    }
});

// Update order tracking entry
router.put("/:id", async (req, res) => {
    try {
        const updatedData = req.body;
        await OrderTracking.update(updatedData, { where: { ID: req.params.id } });
        const updatedOrderTracking = await OrderTracking.findAll({ where: { OrderNo: req.body.OrderNo } });
        res.json(updatedOrderTracking);
    } catch (err) {
        console.error("Error updating OrderTracking:", err);
        res.status(500).send("Server error");
    }
});

// Fetch orders with milestones
router.get("/orders/milestones", async (req, res) => {
    console.log("Fetching orders and milestones...");
    try {
        const orders = await Order.findAll({
            include: [{ model: OrderTracking, attributes: ["Milestone", "MilestoneDate"] }],
        });

        const taskTrack = await TaskTracking.findAll();
        if (!orders.length) {
            console.log("No orders found");
            return res.status(404).json({ message: "No orders found" });
        }

        // Create result array
        const result = orders.map(order => {
            const milestones = {};

            // Initialize milestones with dates
            Object.entries(order.OrderTrackings).forEach(([_, tracking]) => {
                milestones[tracking.Milestone] = { value: tracking.MilestoneDate, status: null };
            });

            // Map statuses from taskTrack
            taskTrack.forEach(task => {
                if (task.OrderNo === order.order_no && milestones[task.Milestone]) {
                    milestones[task.Milestone].status = task.StatusCode;
                }
            });

            return {
                season: order.season,
                style: order.style,
                orderNo: order.order_no,
                buyer: order.buyer,
                owner: order.owner,
                quantity: order.quantity,
                milestones,
            };
        });

        return res.json(result);
    } catch (err) {
        console.error("Error fetching orders and milestones:", err);
        return res.status(500).send("Error while fetching data");
    }
});


// Merge Orders and Milestones into OrderTracking
async function mergeOrder() {
    const orders = await Order.findAll();
    const milestones = await Milestone.findAll();
    
    console.log("Fetched Orders:", orders.length);
    console.log("Fetched Milestones:", milestones.length);
    
    if (orders.length === 0 || milestones.length === 0) {
        console.log("No orders or milestones found. Skipping merge.");
        return;
    }

    const bulkData = [];
    for (const order of orders) {
        const exFacDate = new Date(order.exfac_date);
        
        milestones.forEach((milestone) => {
            const calculatedDate = new Date(exFacDate);
            calculatedDate.setDate(calculatedDate.getDate() - milestone.Leadtime);

            bulkData.push({
                ID: `${order.buyer}-${order.order_no}-${milestone.Milestone}`,
                OrderNo: order.order_no,
                Customer: order.buyer,
                OrderQty: order.quantity,
                ExFacDate: order.exfac_date,
                Milestone: milestone.Milestone,
                MilestonSeqNum: milestone.MilestonSeqNum,
                TaskDescription: milestone.TaskDescription,
                Leadtime: milestone.Leadtime,
                CalculatedDate: calculatedDate.toISOString().split("T")[0],
                ApprovedDate: calculatedDate.toISOString().split("T")[0],
                MilestoneDate: calculatedDate.toISOString().split("T")[0],
                Department: milestone.Department,
                Status: "Pending",
                StatusCode: "",
                DelayDays: 0,
                DelayReason: "",
                Createdate: new Date().toISOString().split("T")[0],
                Owner: order.owner,
                Stage: "",
                ApprLeadTime: milestone.Leadtime,
                ApprDate: new Date().toISOString().split("T")[0]
            });
        });
    }

    console.log("Prepared bulk data:", bulkData.length);
    
    if (bulkData.length > 0) {
        await OrderTracking.bulkCreate(bulkData);
        console.log("OrderTracking data inserted successfully.");
    } else {
        console.log("No data to insert in OrderTracking.");
    }
}

// Uncomment this to run mergeOrder manually
 //mergeOrder();
// frontend should be link to the bulk data 
module.exports = router;
