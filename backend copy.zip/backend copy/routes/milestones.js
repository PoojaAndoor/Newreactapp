
const express = require("express");
const router = express.Router();
const { Milestone } = require("../models/model");

// ✅ Create a new milestone
router.post("/", async (req, res) => {
    try {
        const milestone = await Milestone.create(req.body);
        res.status(201).json(milestone);
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// ✅ Fetch milestones for a specific order
router.get("/:orderNo", async (req, res) => {
    try {
        const { orderNo } = req.params;
        const milestones = await Milestone.findAll({ where: { OrderNo: orderNo } });
        res.json(milestones);
    } catch (error) {
        console.error(error);
        res.status(500).send("Server error");
    }
});

// ✅ Save updated milestones (Only updates MilestoneDate & Status)
router.put("/save", async (req, res) => {
    try {
        const { milestones } = req.body;

        for (const milestone of milestones) {
            await Milestone.update(
                {
                    MilestoneDate: milestone.MilestoneDate,
                    Status: milestone.Status
                },
                { where: { MilestoneID: milestone.MilestoneID } }
            );
        }

        res.json({ success: true, message: "Milestones updated successfully" });
    } catch (error) {
        console.error("Error updating milestones:", error);
        res.status(500).send("Server error");
    }
});

// ✅ Sample milestone data for testing
const milestones = [
    {
        MilestoneID: "Milestone1",
        MilestonSeqNum: 0,
        Customer: "Customer1",
        Milestone: "Ex-Factry",
        TaskDescription: "Ex Factory",
        Leadtime: 0,
        WashLT: 0,
        Department: "Merchandiser",
    },
    {
        MilestoneID: "Milestone2",
        MilestonSeqNum: 1,
        Customer: "Customer1",
        Milestone: "Ord Rcvd",
        TaskDescription: "Order Reciept",
        Leadtime: 92,
        WashLT: 92,
        Department: "Merchandiser",
    },
    {
        MilestoneID: "Milestone3",
        MilestonSeqNum: 2,
        Customer: "Customer1",
        Milestone: "Bom Gen",
        TaskDescription: "BOM Generation",
        Leadtime: 89,
        WashLT: 89,
        Department: "Merchandiser",
    },
    {
        MilestoneID: "Milestone4",
        MilestonSeqNum: 3,
        Customer: "Customer1",
        Milestone: "SizeSet App",
        TaskDescription: "Size Set Approval",
        Leadtime: 84,
        WashLT: 84,
        Department: "Sampling",
    },
    {
        MilestoneID: "Milestone5",
        MilestonSeqNum: 4,
        Customer: "Customer1",
        Milestone: "PP Smpl Cmp",
        TaskDescription: "PP Sample Completion",
        Leadtime: 80,
        WashLT: 80,
        Department: "Sampling",
    },
    {
        MilestoneID: "Milestone6",
        MilestonSeqNum: 5,
        Customer: "Customer1",
        Milestone: "PP Smpl App",
        TaskDescription: "PP Sample Approval",
        Leadtime: 74,
        WashLT: 74,
        Department: "Sampling",
    }
];

// ✅ Function to populate the database (Run once)
function createMilestone() {
    Milestone.bulkCreate(milestones)
        .then(() => {
            console.log("Milestones created successfully");
        })
        .catch((err) => {
            console.error("Error creating milestones:", err);
        });
}

// Uncomment the below line to populate the database initially
// createMilestone();

module.exports = router;
