const express = require("express");
const cors = require("cors");
const listEndpoints = require('express-list-endpoints');
const bodyParser = require("body-parser");
const session = require("express-session");
const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;
const sequelize = require("./sequelizeInstance");
const path = require('path');
const { User } = require('./models/model');

const orderRoutes = require("./routes/order");
const milestoneRoutes = require("./routes/milestones");
const orderTrackingRoutes = require("./routes/ordertracking");
const taskTrackingRoutes = require("./routes/tasktracking");

//require("dotenv").config(); // Load environment variables
require('dotenv').config({ path: '../.env' });


const app = express();
const port = 3006;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Session middleware
app.use(
    session({
        secret: process.env.SESSION_SECRET || "secret",
        resave: false,
        saveUninitialized: true,
    })
);
// app.get("/tasktracking", (req, res) => {
//     // Return all task tracking data
//     res.json(taskTrackingData);
//   });
  

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

// Passport serialization
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user, done) => done(null, user));

// Google OAuth Strategy
passport.use(
    new GoogleStrategy(
        {
            clientID: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
            callbackURL: "http://localhost:3006/auth/google/callback",
        },
        async (accessToken, refreshToken, profile, done) => {
            console.log('profile', profile)
            try {
                let user = await User.findOne({ where: { googleId: profile.id } });
                // console.log(user)
                if (!user) {
                    user = await User.create({
                        googleId: profile.id,
                        displayName: profile.displayName,
                        email: profile.emails[0].value,
                        profilePic: profile.photos ? profile.photos[0].value : null,
                        password: '12345678'
                    });
                }

                return done(null, user);
            } catch (error) {
                console.error('Error during Google OAuth:', error);
                return done(error, null);
            }
        }
    )
);

// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, '../frontend/login.html'));
//     //res.send("Welcome to the backend server! No login page for now.");
// });

app.use(express.static(path.join(__dirname, '../frontend')));
// Authentication routes
app.get('/auth/google', (req, res, next) => {
    req.logout((err) => {
        if (err) {
            console.error('Error during logout:', err);
            return res.status(500).send('Error during logout');
        }
        next();
    });
}, passport.authenticate("google", { scope: ["profile", "email"], prompt: "select_account", }));

app.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/' }),
    (req, res) => {
        // console.log('11111111111', req.user)
        // Redirect to frontend dashboard
        // res.send(req.user)
        // res.redirect('/index.html');
        res.redirect(`/index.html?user=${encodeURIComponent(JSON.stringify(req.user))}`);
    }
);


app.get("/profile/:user_id", async (req, res) => {
    console.log(req.params)
    if (req.params.user_id) {
        let userData = await User.findOne({ raw: true, where: { user_id: req.params.user_id } })
        return res.json({ user: userData });
    } else if (!req.isAuthenticated()) {
        return res.status(401).send("Not authenticated");
    }
    return res.json({ user: req.user });
});

app.post("/user/login", async (req, res) => {
    console.log(req.body)
    try {
        let { username, password } = req.body
        let finduser = await User.findOne({ raw: true, where: { email: username, password: password } })
        if (!finduser) return res.status(500).send({ error: 'No user found' })
        return res.status(200).json(finduser)
    } catch (error) {
        return res.status(500).json({ error: 'Error while finding user'});
    }
});

app.get("/logout", (req, res) => {
    req.logout((err) => {
        if (err) {
            console.error("Error during logout:", err);
            return res.status(500).send("Error logging out");
        }
        // Destroy the session explicitly
        req.session.destroy((err) => {
            if (err) {
                console.error("Error destroying session:", err);
                return res.status(500).send("Error destroying session");
            }
            // Redirect to login page
            res.redirect('/login.html');
        });
    });
});

// API routes
app.use("/orders", orderRoutes);
app.use("/milestones", milestoneRoutes);
app.use("/ordertracking", orderTrackingRoutes);
app.use("/tasktracking", taskTrackingRoutes);

// Start the server and sync database
sequelize.sync({ force: false })
    .then(() => {
        console.log("Database & tables synced!");
        // importData();   
        app.listen(port, () => {
            console.log(`Server running at http://localhost:${port}`);
        });
    })
    .catch(err => console.error("DB Sync Error:", err));


    const fs = require("fs");
    const { Order, OrderTracking, Milestone, TaskTracking } = require("./models/model");
    
    async function exportData() {
        try {
            const orders = await Order.findAll({ raw: true });
            const orderTracking = await OrderTracking.findAll({ raw: true });
            const milestones = await Milestone.findAll({ raw: true });
            const taskTracking = await TaskTracking.findAll({ raw: true });
            const users = await User.findAll({ raw: true });
    
            const data = { orders, orderTracking, milestones, taskTracking, users };
            fs.writeFileSync("backup.json", JSON.stringify(data, null, 2));
    
            console.log("✅ Data Exported Successfully!");
        } catch (err) {
            console.error("❌ Export Failed:", err);
        }
    }
    
    // exportData();

    async function importData() {
        try {
            const rawData = fs.readFileSync("backup.json");
            const data = JSON.parse(rawData);
    
            await Order.bulkCreate(data.orders);
            await OrderTracking.bulkCreate(data.orderTracking);
            await Milestone.bulkCreate(data.milestones);
            await TaskTracking.bulkCreate(data.taskTracking);
            await User.bulkCreate(data.users);
    
            console.log("✅ Data Imported Successfully into SQLite!");
        } catch (err) {
            console.error("❌ Import Failed:", err);
        }
    }